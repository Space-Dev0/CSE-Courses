// This program prints the index and value of largest element of array
#include<stdio.h>

int arrmax (int* arr,int a); //Prototype function

int main ()
{
    int i,a;
    printf("Enter size of Array: ");
    scanf("%d",&a);
    int arr[a];
    printf("Enter the Array elements sperated by space: ");
    for ( i = 0; i < a; i++)
        scanf("%d",&arr[i]);
    printf("Index: %d\n",arrmax(arr,a)); //Calling arrmax
    printf("Element is: %d\n",arr[arrmax(arr,a)]);
}

int arrmax(int* arr, int a) //Defining arrmax
{
    int i,b,c;
    b = arr[0];
    c = 0;
    for ( i = 0; i < a; i++)
    {
        if (b<arr[i])
        {
            b = arr[i];
            c = i;
        }    
    }
    return c;

}