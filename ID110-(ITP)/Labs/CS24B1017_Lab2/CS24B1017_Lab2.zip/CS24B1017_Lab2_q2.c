//This program calculates the Total Amount and Interest for Guddu and Bablu
#include<stdio.h>

//Prototype function
double finalAmount(double P, double R,int N, int T);
double compoundInterest(double A, double P);

int main ()
{
    int N,T;
    double P,R; 
    printf("Enter the Principal: ");
    scanf("%lf",&P);
    printf("Enter the Annual Interest Rate: ");
    scanf("%lf",&R);
    printf("Enter the Compounding Frequency: ");
    scanf("%d",&N);
    printf("Enter the Duration: ");
    scanf("%d",&T);
    printf("Final Amount: %.2lf\n",finalAmount(P,R,N,T)); //Calling FinalAmount
    printf("Compound Interest: %.2lf\n",compoundInterest(finalAmount(P,R,N,T),P)); //Calling FinalAmount In CompoundInterest 
}

double finalAmount(double P, double R,int N, int T)
{
    double a,b;
    int i;
    b = 1+(R/(100*N));
    for ( i = 0,a = 1; i < N*T; i++)
        a = a*b;
    a = a*P;
    return a;
}

double compoundInterest(double A, double P)
{
    return A-P;
}