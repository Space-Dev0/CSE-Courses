// This program calculates the mean, median, maximum, minimum of entered array
#include<stdio.h>
int main()
{
    int i,size,min,max;
    float mean, median;

    //Inputing Array
    printf("Enter the size of array: ");
    scanf("%d",&size);
    int arr[size];
    printf("Enter the elements in one line separated by space in ascending order: ");
    for ( i = 0; i < size; i++)
        scanf("%d",&arr[i]);

    //Calculating Mean
    for ( i = 0, mean = 0; i < size; i++)
        mean = mean + arr[i];
    mean = mean/size;

    //Calculating Median
    if (size%2 == 0)
        median = (arr[(size-1)/2]+arr[size/2])/2.0;
    else
        median = arr[(size-1)/2];

    //Calculating Minimum and Maximum
    min = arr[0];
    max = arr[size-1];
    
    printf("Mean: %.2f, Median: %.2f, Max: %d, Min: %d\n",mean,median,max,min);
}