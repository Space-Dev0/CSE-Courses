// This program merges Luffy's and Zoro's Favourite Soda arrays
#include<stdio.h>
int main()
{
    int i,j,b,d, size_L, size_Z;
    
    //Taking input for both
    printf("Enter the size of Luffy's soda array: ");
    scanf("%d",&size_L);
    printf("Enter the elements of Luffy's soda array seperated by space: ");
    int arr_L[size_L];
    for ( i = 0; i < size_L; i++)
        scanf("%d",&arr_L[i]);
    
    printf("Enter the size of Zoro's soda array: ");
    scanf("%d",&size_Z);
    printf("Enter the elements of Zoro's soda array seperated by space: ");
    int arr_Z[size_Z];
    for ( i = 0; i < size_Z; i++)
        scanf("%d",&arr_Z[i]);
    
    //Making an array called Merge and storing all elements of Luffy's Array
    int Merge[size_L+size_Z];
    for ( i = 0; i < size_L; i++)
        Merge[i] = arr_L[i];

    //Making the rest of the elements zero in Merge
    for ( i = size_L; i < size_L+size_Z; i++)
        Merge[i]=0;
    
    //Comparing all and storing only those which don't match with any of the elements already in merge
    b = size_L;
    for ( i = 0; i < size_Z; i++)
    {
        for ( j = 0,d =0; j < size_L; j++)
        {
            if (Merge[j] == arr_Z[i])
                d++;
        }
        if (d==0)
        {
            Merge[b]= arr_Z[i];
            b++;
        }
    }
    //Printing Merge until an element becomes zero or the array is exhausted
    printf("\nThe merged array is: ");
    for ( i = 0; i < size_L+size_Z && Merge[i]!=0; i++)
        printf("%d ",Merge[i]);
    printf("\n");
    
}