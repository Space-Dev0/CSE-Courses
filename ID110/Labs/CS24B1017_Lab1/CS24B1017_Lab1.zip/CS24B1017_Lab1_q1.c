// This program checks for pallindromes
#include<stdio.h>
int main()
{
    int num, num_copy, digit, num2;
    printf("Enter a number: ");
    scanf("%d",&num);
    num2 = 0;
    //This for loop reverses the number and stores it in num2
    for ( num_copy = num; num_copy >= 1; num_copy = num_copy/10)
    {
        digit = num_copy%10;
        num2 = num2*10+digit;
    }
    //checking for pallindrome
    if (num2 == num)
        printf("true\n");
    else
        printf("false\n");
}