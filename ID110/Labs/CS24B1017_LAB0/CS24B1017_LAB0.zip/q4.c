//  //This program is for changing the given loop to while loop
#include<stdio.h>
int main ()
{
    int m;
    // Given loop
    // for ( ; scanf ("%d",&m)!= -1; )
    // printf ("%d",m);
    while(scanf("%d",&m)!= -1)
    printf("%d",m);
}